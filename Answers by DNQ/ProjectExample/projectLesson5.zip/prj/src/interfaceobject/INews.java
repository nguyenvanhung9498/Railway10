package interfaceobject;

public interface INews {
	public void display();
	public float caculator();

}
