package interfaceobject;

public interface GiaoTiep {

	public void giongNoi(String ngonNgu);
	
	
}
