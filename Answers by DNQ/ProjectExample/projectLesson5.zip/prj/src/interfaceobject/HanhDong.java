package interfaceobject;

//Interface khong co thuoc tinh
//chi dinh nghia kieu tra ve, ten, parameter cua cac phuong thuc
//cac Object impliment Interface thi phai Override lai cac phuong thuc va cai dat chung
public interface HanhDong {
	
	public void boi();
	
	public void chay();
	
	public void chayBonChan();
	
	/**
	 * 
	 * @param userName
	 * @param password
	 * @return 1 login thanh cong tk da dc tao, 2 login loi sai tk, 3 login sai mk, 4 tk chua dc tao
	 */
	public int Login(String userName, String password);
	
	
	
	public int createAccount( String useeName, String password);
}
