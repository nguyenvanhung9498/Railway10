package main;

import java.util.Scanner;

import object.News;

public class MyNews {
	
	static News[] mangNews = new News[10];
	static int indexMang = 0;

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int inputScan = -1;
		
		do {
			System.out.println(" 1 -  Chen them 1 obj New.");
			System.out.println(" 2 -  In ra danh sach News. ");
			System.out.println(" 3 -  Tinh diem rate trung binh. ");
			System.out.println(" 0 -  Thoat chuong trinh. ");
			System.out.println("Nhap lua chon cua ban: ");
			inputScan = scanner.nextInt();
			scanner.nextLine();
			switch (inputScan) {
			case 0: {
				inputScan = 0;
				System.out.println("ket thuc chuong trinh");
				break;
			}
			case 1: {
				insertObjectNews();
				break;
				
			}
			case 2: {
				for (int i = 0; i < indexMang; i++) {
					System.out.println(mangNews[i].toString());
				}
				System.out.println();
				break;
				
			}
			case 3: {
				break;
				
			}
			default:
//				throw new IllegalArgumentException("Unexpected value: " + inputScan);
			}
			
		} while (inputScan != 0);

	}

	private static void insertObjectNews() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhap content new : ");
		String content = scanner.nextLine(); 
		System.out.println("Nhap publicDate : ");
		String publicDate = scanner.nextLine(); 
		System.out.println("Nhap Author : ");
		String author = scanner.nextLine(); 
		System.out.println("Nhap  diem danh gia: ");
		float ratePoint = scanner.nextFloat();
		scanner.nextLine();
		mangNews[indexMang] = new News(content, publicDate, author, ratePoint) ;
		indexMang++;
	}

}
