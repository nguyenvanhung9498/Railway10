package main;

import object.Person;
import object.Student;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person person = new Person(18, "Nam") {
			@Override
			public String phuongThucB() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		Person person4 = new Student( "Nam", 18);
		Person person3 = new Person() {
			@Override
			public String phuongThucB() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		Person person2 = new Student("Nam", 19);
//		Person person2 = new Person( "NamANh", 20);
		
		//pham vi truy cap la public goi o moi noi
		person.phuongThucA();
		
		
		//dung doi tuong Student
		Student student = new Student(18);
		String s = student.setTuoi("120");
		
		System.out.println("Tuoi hoc sinh la = " + student.getTuoi());
//		System.out.println("\n\nString tuoi  = " + );
		
	
	}

}
