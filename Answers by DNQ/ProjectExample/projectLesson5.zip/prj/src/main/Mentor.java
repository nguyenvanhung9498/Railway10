package main;

import object.Person;

public class Mentor extends Person{
	
	
	public void phuongThuc() {
		//Mentor ke thua Person nen goi duoc cac thuoc tinh cos muc do truy cap laf Protected
		super.hoVaTen = "Nguyen Van B";
	}
	
	
	@Override
	public String phuongThucB() {
		// TODO Auto-generated method stub
		return null;
	}
}
