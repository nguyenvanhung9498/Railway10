package object;

import interfaceobject.INews;

public class News implements INews{
	private int id;
	private String title;
	private String content;
	private String publichDate;
	private String author;
	private float avenrageRate;
	private int[] rates = {1,2,3};
	
	public News() {
		
	}
	
	
	public News(int id) {
		super();
		this.id = id;
	}



	public News(String title, String content, String publichDate, String author, float avenrageRate) {
		super();
		this.title = title;
		this.content = content;
		this.publichDate = publichDate;
		this.author = author;
		this.avenrageRate = avenrageRate;
	}



	public News(int id, String title, String content, String publichDate, String author, float avenrageRate) {
		super();
		this.id = id;
		this.title = title;
		this.content = content;
		this.publichDate = publichDate;
		this.author = author;
		this.avenrageRate = avenrageRate;
	}
	public News(String content2, String publicDate, String author2, float ratePoint) {
		this.content = content2;
		this.publichDate = publicDate;
		this.author = author2;
		this.avenrageRate = ratePoint;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPublichDate() {
		return publichDate;
	}
	public void setPublichDate(String publichDate) {
		this.publichDate = publichDate;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	

	public float getAvenrageRate() {
		return avenrageRate;
	}


	public void setAvenrageRate(float avenrageRate) {
		this.avenrageRate = avenrageRate;
	}


	public String question1A() {
		return "News [title=" + title + ", content=" + content + ", publichDate=" + publichDate + ", author=" + author
				+ ", avenrageRate=" + avenrageRate + "]";
	}
	
	

	
	
	
	@Override
	public String toString() {
		return "News [content=" + content + ", publichDate=" + publichDate + ", author=" + author + ", avenrageRate="
				+ avenrageRate + "]";
	}


	@Override
	public void display() {
		System.out.println(question1A());
		
	}


	@Override
	public float caculator() {
		float ketQua = 0f;
		ketQua = (rates[0] + rates[1] + rates[2])/ 3f;
		return ketQua;
	}
}
