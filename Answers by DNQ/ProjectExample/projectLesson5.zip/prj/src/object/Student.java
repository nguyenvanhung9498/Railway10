package object;

//Student ke thua Class Person
public class Student extends Person{
	
	private int sbd;
	private String tenLopHoc;
	private String chucVu;
	
	//Ham khoi tao giong
	public Student() {
		super.setTuoi(18);
		int tuoi = getTuoi();
	}

	public Student(int tuoi) {
		//ke thua ham khoi tao 1 tham cua thang Person 
		super(tuoi);
		
	}
	
	public Student(String ten, int tuoi) {
		//ke thua ham khoi tao 2 tham so cua thang Cha
		super(ten, tuoi);
		// TODO Auto-generated constructor stub
	}
	
	
	//ghi de toan tu
//	@Override
	public void setTuoi(int tuoi) {
		super.setTuoi(tuoi);
		if (tuoi > 100) {
			System.out.println("Student gia qua khong hoc ");
			setTuoiTuyChinh(tuoi);
		}
		
		System.out.println("Student set tuoi");
//		setTuoiTuyChinh(tuoi);
	}
	
	//Overload la phuong thuc giong ten nhung khac parameter, co the khac kieu tra ve
	public String setTuoi(String tuoi) {
//		super.setTuoi(tuoi);
//		System.out.println("chay vao set tuoi day");
		setTuoiTuyChinh(Integer.parseInt(tuoi));
		return "Tuoi student la = " + tuoi;
	}
	
	
	
	@Override
	public String phuongThucB() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	//ke thua ham khoi tao
//	public Student(String ten, int tuoi) {
//		super.setTen(ten +"abc");
//		super.setTuoi(15);
//	}
	
	
	
	
	
}
