package object;

import interfaceobject.GiaoTiep;
import interfaceobject.HanhDong;

public class Animal implements HanhDong, GiaoTiep{

	@Override
	public void boi() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void chay() {
		
		
	}

	@Override
	public void giongNoi(String ngonNgu) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void chayBonChan() {
		
	}

	@Override
	public int Login(String userName, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int createAccount(String useeName, String password) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	

	
	
	

	

	
}
