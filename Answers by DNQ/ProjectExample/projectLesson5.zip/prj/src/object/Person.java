package object;

public abstract class Person {
	// chi su dung o ben trong Class khai bao no
	// de dong goi che giau du lieu.
	private int tuoi;
	private int chieuCao;
	private float canNang;
	private String ten;
	private String soDo;

	// de mac dinh la kieu default
	// truy cap duoc o trong class va cac Class trong package
	String ho;

	// Mentor ke thua Person nen goi duoc cac thuoc tinh cos muc do truy cap laf
	// Protected
	protected String hoVaTen;

	// Cac ham khoi tao
	//Loai 1 Ham khoi tao khong tham so
	public Person() {
		
	}

	//Loai 2 ham khoi tao co tham so
	public Person(int tuoi) {
		this.tuoi = tuoi;
	}
	
	
	public Person(String ten) {
		this.ten = ten;
	}
	
	public Person(int chieuCao, String ten) {
		
	}
	
	/**
	 * Day la ham khoi tao 2 tham so (ten , tuoi)
	 * @param ten la kieu du lieu String
	 * @param tuoi : int 
	 */
	public Person(String ten, int tuoi) {
		
	}
	

	// public la co the goi duoc o bat ky dau trong project
	public void phuongThucA() {
		ho = "aaa ";
		noiThemTuVaoTen();
	}

	private void noiThemTuVaoTen() {
		ten = ten + "abcd";
	}

	/**
	 * Phuon thuc tra ve tuoi cua Person
	 * @return tuoi : int
	 */
	public int getTuoi() {
		return tuoi;
	}

	public void setTuoi(int tuoi) {
		System.out.println("Person set tuoi");
		if (tuoi < 0) {
			System.out.println("tuoi khong duoc am ");
			return;
		}
			this.tuoi = tuoi;
		
	}
	
	public void setTuoiTuyChinh(int tuoi) {
		this.tuoi = tuoi;
	}

	public String getTen() {
		return ten;
	}

	public void setTen(String ten) {
		this.ten = ten;
	}

	public String getHo() {
		return ho;
	}

	public void setHo(String ho) {
		this.ho = ho;
	}

	public String getHoVaTen() {
		return hoVaTen;
	}

	public void setHoVaTen(String hoVaTen) {
		this.hoVaTen = hoVaTen;
	}

	public int getChieuCao() {
		return chieuCao;
	}

	public void setChieuCao(int chieuCao) {
		this.chieuCao = chieuCao;
	}

	public float getCanNang() {
		return canNang;
	}

	public void setCanNang(float canNang) {
		this.canNang = canNang;
	}

	
	public abstract String phuongThucB();
	
}
